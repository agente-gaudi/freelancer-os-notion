# Freelancer OS & AI Hub — Quick Start Guide
## Your Notion template for freelancers who use AI and automation

---

## ⚡ Setup in 15 Minutes

### Step 1 — Duplicate the Template (2 min)
1. Open the Notion template link sent to your email
2. Click **"Duplicate"** in the top-right corner
3. Select your Notion workspace
4. Done! The template is now yours.

### Step 2 — Configure Your Dashboard (5 min)
1. Open the **📊 Dashboard** page
2. Set your **Monthly Goal** (default: $200 USD)
3. Update the currency filter to your preferred currency
4. Bookmark the Dashboard as your Notion homepage

### Step 3 — Add Your First Client (3 min)
1. Go to **👥 Client CRM**
2. Click **"+ New"** to add a client
3. Fill in: Name, Email, Platform (where you met), Status
4. Set a **Next Follow-up** date

### Step 4 — Create Your First Project (3 min)
1. Go to **📁 Project Manager**
2. Click **"+ New"** to create a project
3. Link it to your client from Step 3
4. Set: Status, Deadline, Agreed Price
5. Open Kanban view to see your workflow

### Step 5 — Log Your First Income (2 min)
1. Go to **💰 Financial Tracker**
2. Click **"+ New"**
3. Fill in: Description, Amount, Payment Method, Date
4. Your Dashboard will automatically update!

---

## 🤖 AI Prompt Library — Getting Started

The template includes 3 pre-loaded prompts:

### Prompt 1: Cold Outreach (Sales)
Use this to write personalized outreach messages for any platform.
Variables: `{PLATFORM}`, `{TARGET_BUSINESS_TYPE}`

### Prompt 2: Service Description Optimizer (Copywriting)
Rewrites any service description to maximize conversions.
Variables: `{PLATFORM}`, `{ORIGINAL_TEXT}`, `{TARGET_BUYER}`

### Prompt 3: n8n Workflow Explainer (Client Communication)
Explains any automation to a non-technical client.
Variables: `{WORKFLOW_DESCRIPTION}`

---

## 🌱 Passive Income Tracker — Best Practices

For each passive project you plant:
1. Add it to **🌱 Passive Income Monitor**
2. Set a **health check** reminder every 7 days
3. If income = $0 for 3 consecutive months → evaluate abandonment
4. Always track the URL and publication date

---

## 🔍 Opportunity Pipeline — Scoring Guide

When evaluating a new opportunity, score it 0-10:

| Criteria | Points |
|----------|--------|
| Legal & ethical | +2 |
| Zero capital required | +2 |
| First income < 14 days | +2 |
| Market proven (others doing it) | +2 |
| Tools available | +1 |
| Personal skill match | +1 |

**Score ≥ 7:** Approve and execute
**Score 4-6:** Research more before deciding
**Score < 4:** Discard

---

## 💡 Pro Tips

- **Check your Dashboard every morning** before starting work
- **Update project progress** at end of each work session
- **Log income immediately** when received (don't batch)
- **Set follow-up dates** for every prospect conversation
- **Rate your prompts** after using them — you'll build a personal AI toolkit

---

## 📬 Support

Questions or feedback? Reach out:
- Email: agente.gaudi@gmail.com
- Response time: 24-48 hours

---

*Thank you for your purchase! This template will be updated regularly.*
*Version 1.0 — Released July 2026*
