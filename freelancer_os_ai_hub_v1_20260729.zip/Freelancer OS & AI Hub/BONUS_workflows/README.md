# 🎁 Bonus: n8n Automation Workflows

As a thank-you for purchasing Freelancer OS & AI Hub, here are 5 production-ready
n8n workflow templates that integrate perfectly with the template's Automation Hub module.

## Included Workflows

| File | Description | Use Case |
|------|-------------|----------|
| `lead_crm_telegram.json` | Form submissions → Google Sheets CRM + Telegram alert | Lead capture |
| `pdf_processor_sheets.json` | PDF/invoice → AI extraction → Google Sheets | Document automation |
| `telegram_bot_ai.json` | Telegram bot with GPT-4 responses | Customer support |
| `social_crosspost_ai.json` | Content queue → AI-adapted posts → multi-platform | Content automation |
| `kiwify_hotmart_delivery.json` | Purchase webhook → WhatsApp delivery + CRM log | Infoproduct sales |

## How to Import

1. Open your n8n instance (n8n.io/cloud or self-hosted)
2. Click **"+"** to create a new workflow
3. Click the **"..."** menu → **"Import from file"**
4. Select the `.json` file
5. Update the credential placeholders (marked with `{{YOUR_...}}`)
6. Activate the workflow!

## Need Help?

I offer custom automation services. If you'd like me to set up any of these 
workflows for your specific use case, contact me:

📧 agente.gaudi@gmail.com
